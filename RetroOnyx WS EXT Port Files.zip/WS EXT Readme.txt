These STL parts were designed to be printed on a Markforged Onyx desktop using Onyx material.
Onyx material on Bambu Labs X1C works well too.

You need USB port pins.  I buy these from Digikey.com and remove them from the part.
https://www.digikey.com/en/products/detail/cnc-tech/1002-021-01000/3466946

You need an assembly jig to help make the pin soldering to the PCB repeatable.
Works quite well.